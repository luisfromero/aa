#include "umaobd.h"


tripline::tripline() {
};

tripline::~tripline()
{
	delete points;
}

void tripline::fill(int n)
{
	npoints = n;
	points = (trippoint**)new trippoint * [n];
}
