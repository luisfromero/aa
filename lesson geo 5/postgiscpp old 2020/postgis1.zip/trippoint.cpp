#include "umaobd.h"

trippoint::trippoint(double x, double y)
{
	latitude = y;
	longitude = x;
};


trippoint::~trippoint()
{

}
