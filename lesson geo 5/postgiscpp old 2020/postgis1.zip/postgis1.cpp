// postgis1.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>
#include "umaobd.h"
#include "gdalparser.h"
#include <libpq-fe.h>
#include <ogrsf_frmts.h>
#include "postgiscpp.h"

void error(const char* mensaje)
{
	fprintf(stderr, mensaje, PQerrorMessage(conn));
	PQclear(result); //Nulo si no hay conexión, pero no da error
	PQfinish(conn);
	finished = true;
}

void query(char* comando, bool clear)
{
	if (finished)return;
	result = PQexec(conn, comando);

	ExecStatusType x = PQresultStatus(result);
	if ((x != PGRES_TUPLES_OK) && (x != PGRES_COMMAND_OK)) {
		fprintf(stderr, comando);
		error(" failed: %s\n");
		return;
	}
	if (clear)PQclear(result);
}


void prepare()
{
	options = { 0 };
	options.header = 1;    /* Ask for column headers           */
	options.align = 1;    /* Pad short columns for alignment  */
	//options.fieldSep = "|";  /* Use a pipe as the field separator*/
	options.fieldSep = const_cast < char*>("|");  /* Use a pipe as the field separator*/
	//conninfo = "dbname = umaobd user=obd_readpriv password=vc0910$$ host=atomic3.dmz.ac.uma.es";
	//conninfo = ;
	//conninfo = "dbname = umaobd user=obd_readpriv password=vc0910$$ host=obd.ac.uma.es";
}

void parseLS(int rec_count, tripline** trip, int mode)
{
	char* tmp;

	for (int i = 0; i < rec_count; i++) {
		tmp = PQgetvalue(result, i, 1);
		trip[i] = new tripline();
		parser->parseGeometry((unsigned char*)tmp, trip[i]);
		tmp = PQgetvalue(result, i, 0);
		sscanf_s(tmp, "%d", &trip[i]->id);
		tmp = PQgetvalue(result, i, 2);
		sscanf_s(tmp, "%d", &trip[i]->npoints);
		tmp = PQgetvalue(result, i, 3);
		sscanf_s(tmp, "%lf", &trip[i]->distance1);
		tmp = PQgetvalue(result, i, 4);
		sscanf_s(tmp, "%lf", &trip[i]->distance2);
		}
}


int readdb()
{
	prepare();
	conn = PQconnectdb(conninfo);
	ConnStatusType pqs = PQstatus(conn);
	if (pqs != CONNECTION_OK) {
		error("Connection to database failed: %s"); return 0;
	}
	else
	{
		finished = false;
		printf("Connection Ok\n");


		query((char*)getFullTracks, false);
		//PQprint(stdout, result, &options);
		ntracks = PQntuples(result);
		tracks = (tripline**) new tripline * [ntracks];
		parseLS(ntracks, tracks,0);
		PQclear(result);

		query((char*)getTrimTracks, false);
		//PQprint(stdout, result, &options);
		ntracks = PQntuples(result);
		trim_tracks = (tripline**) new tripline * [ntracks];
		parseLS(ntracks, trim_tracks,1);
		PQclear(result);

		query((char*)getSamples, false);
		nsamples = PQntuples(result);
		samples = new sample[nsamples];
		//parseSamples(nsamples);
		PQclear(result);
	}
}




int main()
{
    std::cout << "Hello World!\n";
	readdb();
}

// Ejecutar programa: Ctrl + F5 o menú Depurar > Iniciar sin depurar
// Depurar programa: F5 o menú Depurar > Iniciar depuración

// Sugerencias para primeros pasos: 1. Use la ventana del Explorador de soluciones para agregar y administrar archivos
//   2. Use la ventana de Team Explorer para conectar con el control de código fuente
//   3. Use la ventana de salida para ver la salida de compilación y otros mensajes
//   4. Use la ventana Lista de errores para ver los errores
//   5. Vaya a Proyecto > Agregar nuevo elemento para crear nuevos archivos de código, o a Proyecto > Agregar elemento existente para agregar archivos de código existentes al proyecto
//   6. En el futuro, para volver a abrir este proyecto, vaya a Archivo > Abrir > Proyecto y seleccione el archivo .sln
